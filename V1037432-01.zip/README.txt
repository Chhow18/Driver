Oracle VirtIO 2.1.0 Drivers for Microsoft Windows on x86/x64
==========================================================

The 2.1.0 release provides:

 - New driver

   - Virto-gpu driver 

     Virtio-gpu driver drives VirtIO VGA as the display device.
 
 - Bug fixes

   VirtIO 2.1.0 fixes some bugs of the VirtIO storage and network driver.

 For more information on installing the VirtIO drivers, please refer to
 the documentation at:

   - https://docs.oracle.com/en/operating-systems/oracle-linux/kvm-virtio/