Oracle VirtIO 2.2.0 Drivers for Microsoft Windows on x86/x64
==========================================================

The 2.2.0 release provides:

 - New driver

   -- Virtio-balloon driver 

     Virtio-balloon driver allows the host to reclaim memory from the guest.

     VirtIO 2.2.0 packs all remaining VirtIO drivers from VirtIO2.1.0.

- New feature

   -- ISO layout

   The new ISO folder layout allows the Windows system installer to automatically
   load the correct driver.

   -- NonKVM to KVM migration support for PCIe devices
 
- Bug fixes

   Support installing and upgrading VirtIO driver for both PCI and PCIe devices

- Documentation

   For more information on installing the VirtIO drivers, please refer to
   the documentation at:

   https://docs.oracle.com/en/operating-systems/oracle-linux/kvm-virtio/